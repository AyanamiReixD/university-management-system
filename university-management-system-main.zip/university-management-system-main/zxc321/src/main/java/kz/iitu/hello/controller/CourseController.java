package kz.iitu.hello.controller;

import kz.iitu.hello.entity.Course;
import kz.iitu.hello.entity.Lesson;
import kz.iitu.hello.service.CourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/courses")
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courseService;

    @PostMapping
    public Course createCourse(@RequestBody Course course) {
        return courseService.saveCourse(course);
    }

    @PostMapping("/{courseId}/lessons")
    public Course addLesson(@PathVariable Long courseId,
                            @RequestBody Lesson lesson) {
        return courseService.addLesson(courseId, lesson);
    }

    @GetMapping("/{id}")
    public Course getCourse(@PathVariable Long id) {
        return courseService.getCourse(id);
    }
}

