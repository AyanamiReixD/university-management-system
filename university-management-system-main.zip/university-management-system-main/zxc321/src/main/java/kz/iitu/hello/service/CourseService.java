package kz.iitu.hello.service;
import jakarta.persistence.*;
import kz.iitu.hello.entity.Course;
import kz.iitu.hello.entity.Lesson;
import kz.iitu.hello.repository.CourseRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class CourseService {

    private final CourseRepository courseRepository;

    public Course saveCourse(Course course) {

        if (course.getLessons() != null) {
            course.getLessons().forEach(l -> l.setCourse(course));
        }

        return courseRepository.save(course);
    }

    @Transactional
    public Course addLesson(Long courseId, Lesson lesson) {

        Course course = courseRepository.findById(courseId)
                .orElseThrow();

        course.addLesson(lesson);

        return courseRepository.save(course);
    }

    public Course getCourse(Long id) {
        return courseRepository.findById(id).orElseThrow();
    }
}