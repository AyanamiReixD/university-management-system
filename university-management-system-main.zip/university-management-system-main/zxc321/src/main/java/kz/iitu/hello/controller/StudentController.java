package kz.iitu.hello.controller;

import kz.iitu.hello.entity.Student;
import kz.iitu.hello.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/students")
@RequiredArgsConstructor
public class StudentController {

    private final StudentService studentService;

    @PostMapping
    public Student createStudent(@RequestBody Student student) {
        return studentService.saveStudent(student);
    }

    @PostMapping("/{studentId}/courses/{courseId}")
    public void assignCourse(@PathVariable Long studentId,
                             @PathVariable Long courseId) {
        studentService.assignStudentToCourse(studentId, courseId);
    }

    @GetMapping("/{id}")
    public Student getStudent(@PathVariable Long id) {
        return studentService.getStudent(id);
    }
}
