package kz.iitu.hello.service;

import kz.iitu.hello.entity.Course;
import kz.iitu.hello.entity.Student;
import jakarta.persistence.*;

import kz.iitu.hello.repository.CourseRepository;
import kz.iitu.hello.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;

    public Student saveStudent(Student student) {
        if (student.getProfile() != null) {
            student.getProfile().setStudent(student);
        }
        return studentRepository.save(student);
    }

    @Transactional
    public void assignStudentToCourse(Long studentId, Long courseId) {

        Student student = studentRepository.findById(studentId)
                .orElseThrow();

        Course course = courseRepository.findById(courseId)
                .orElseThrow();

        student.addCourse(course);

        studentRepository.save(student);
    }

    public Student getStudent(Long id) {
        return studentRepository.findById(id).orElseThrow();
    }

    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }
}